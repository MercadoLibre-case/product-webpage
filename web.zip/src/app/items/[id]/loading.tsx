export default function Loading() {
  return <p>Carregando produto...</p>;
}
